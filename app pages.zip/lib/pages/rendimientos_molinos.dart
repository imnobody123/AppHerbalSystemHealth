import 'package:app_registro_rendimientos/models/equipo_trabajo.dart';
import 'package:app_registro_rendimientos/models/operadores.dart';
import 'package:app_registro_rendimientos/services/operadores_service.dart';
import 'package:flutter/material.dart';
import '../models/control_entrada_molino.dart';
import '../models/proceso_salida.dart';
import '../models/seccion_proceso.dart';
import '../services/controles_service.dart';
import '../config/api_config.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'procesos_en_curso.dart';

class RendimientosMolinos extends StatefulWidget 
{
  final int? idProcesoMolino;

  const RendimientosMolinos({
    super.key,
    this.idProcesoMolino
  });

  @override
  State<RendimientosMolinos> createState() => _RendimientosMolinos();
}

class _RendimientosMolinos extends State<RendimientosMolinos> 
{
  String? tipoProceso;

  List<ControlEntradaMolino> controles = [];
  ControlEntradaMolino? controlSeleccionado;
  bool cargando = true;

  List<ProcesoSalida> procesos = 
  [
    ProcesoSalida(nombre: 'Mesa de Trabajo'),
    ProcesoSalida(nombre: 'Molino'),
    ProcesoSalida(nombre: 'Tamizado'),
    ProcesoSalida(nombre: 'Tolva de imanes'),
    ProcesoSalida(nombre: 'Charolas de desinfección'),
  ];
  TextEditingController observacionesController = TextEditingController();

  EquipoTrabajo? equipoTrabajoSeleccionado;
  List<EquipoTrabajo> equipoTrabajo = 
  [
    EquipoTrabajo(idEquipo: 1, descripcion: "Molino 1"),
    EquipoTrabajo(idEquipo: 2, descripcion: "Molino 2"),
    EquipoTrabajo(idEquipo: 3, descripcion: "Molino 3"),
    EquipoTrabajo(idEquipo: 4, descripcion: "Molino 4"),
    EquipoTrabajo(idEquipo: 5, descripcion: "TAMIZ"),
    EquipoTrabajo(idEquipo: 6, descripcion: "COLADOR"),
    EquipoTrabajo(idEquipo: 7, descripcion: "NUTRIBULLER")  
  ];

  List<Operadores> operadores = [];

  final List<SeccionProceso> secciones = 
  [
    SeccionProceso(nombre: 'Mesa de Trabajo', idArea: 1),
    SeccionProceso(nombre: 'Molino', idArea: 2),
    SeccionProceso(nombre: 'Tamizador', idArea: 3),
    SeccionProceso(nombre: 'Tolva de imanes', idArea: 4),
    SeccionProceso(nombre: 'Charolas de desinfección', idArea: 5),
  ];

  @override
  void initState() 
  {
    super.initState();
    _cargarControles();
    _cargarOperadores();

    if (widget.idProcesoMolino != null) {
          _cargarProcesoParaEditar(widget.idProcesoMolino!);
    }
  }

  Future<void> _cargarProcesoParaEditar(int idProcesoMolino) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/ProcesoMolinoCompleto/ObtenerProcesoCompleto/$idProcesoMolino'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode != 200) {
        debugPrint('No se pudo cargar el proceso');
        return;
      }

      final json = jsonDecode(response.body);

      setState(() {
        observacionesController.text = json['observaciones'] ?? '';
      });

      final List detalles = json['detalles'] ?? [];

      for (final d in detalles) {
        final int idArea = d['idAreaTrabajoMolinos'];

        SeccionProceso? seccion;

        for (final s in secciones) {
          if (s.idArea == idArea) {
            seccion = s;
            break;
          }
        }

        if (seccion == null) continue;

        setState(() {
          seccion?.activo = true;

          // 📅 Fechas
          seccion?.fechaEntrada = DateTime.tryParse(d['fechaEntrada'] ?? '');
          seccion?.fechaSalida = DateTime.tryParse(d['fechaSalida'] ?? '');

          // ⏰ Horas (vienen como DateTime)
          seccion?.horaEntrada = parseTimeSpan(d['horaEntrada']);
          seccion?.horaSalida  = parseTimeSpan(d['horaSalida']);

          // ⚖ Cantidades
          seccion?.cantidadEntrada =
              (d['cantidadEntrada'] as num?)?.toDouble();

          seccion?.cantidadEntradaCtrl.text =
            seccion.cantidadEntrada?.toString() ?? '';

          seccion?.cantidadSalida =
              (d['cantidadSalida'] as num?)?.toDouble();

          seccion?.cantidadSalidaCtrl.text =
            seccion.cantidadSalida?.toString() ?? '';

          final polvo = (d['cantidadPolvo'] as num?)?.toDouble() ?? 0;
          final te = (d['cantidadTe'] as num?)?.toDouble() ?? 0;

          if (polvo > 0)
          {
            seccion?.cantidadPolvo = polvo;
            seccion?.cantidadPolvoCtrl.text = polvo.toString();
          } 
          if (te > 0)
          {
            seccion?.cantidadTe = te;
            seccion?.cantidadTeCtrl.text = te.toString();
          } 
          
          debugPrint('El polvo es $polvo y el te es $te');

          // 👷 Operadores
          seccion?.operadoresIds =
              List<int>.from(d['operadoresIds'] ?? []);

          // ⚙ Equipo de trabajo
          final int? idEquipo = d['idEquipoTrabajo'];

          if (idEquipo != null) {
            EquipoTrabajo? equipo;

            for (final e in equipoTrabajo) {
              if (e.idEquipo == idEquipo) {
                equipo = e;
                break;
              }
            }

            if (equipo != null) {
              seccion?.equipoSeleccionado = equipo;
            }
          }
        });
      }
    } catch (e) {
      debugPrint('Error cargando proceso: $e');
    }
  }

  TimeOfDay? parseTimeSpan(String? value) {
    if (value == null || value.isEmpty) return null;

    final parts = value.split(':');
    if (parts.length < 2) return null;

    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);

    if (hour == null || minute == null) return null;

    return TimeOfDay(hour: hour, minute: minute);
  }

  Future<void> _cargarControles() async 
  {
    try 
    {
      final data = await fetchControles('/EntradasMolinosDetalles/controlesMP_EntradaMolinos');
      setState(()
      {
        controles = data;
        cargando = false;
      });
    } 
    catch (e)
    {
      cargando = false;
      debugPrint('Error: $e');
    }
  }

  Future<void> _cargarOperadores() async 
  {
    try 
    {
      final data = await fetchOperadores();
      setState(()
      {
        operadores = data;
      });
    } 
    catch (e)
    {
      cargando = false;
      debugPrint('Error: $e');
    }
  }

  Future<void> _enviarProceso() async {
    // 1️⃣ Validaciones básicas
    if (controlSeleccionado == null) {
      _mostrarError('Faltan datos obligatorios');
      return;
    }

    final confirmar = await _mostrarConfirmacion(
      widget.idProcesoMolino == null
          ? "¿Está seguro/a que desea registrar este proceso?"
          : "¿Está seguro/a que desea actualizar este proceso?"
    );

    if (confirmar != true) return;

    // 2️⃣ Armar lista de detalles
    final detalles = secciones
        .where((s) => s.activo)
        .map((s) {
          final horaEntradaDt = _combinarFechaHora(
            s.fechaEntrada!,
            s.horaEntrada!,
          );

          final horaSalidaDt = _combinarFechaHora(
            s.fechaSalida!,
            s.horaSalida!,
          );

          return {
            // 🔑 CLAVE PARA UPDATE
            "idProcesoMolinoDetalle": widget.idProcesoMolino != null
                ? (s.idProcesoMolinoDetalle ?? 0)
                : 0,

            "idAreaTrabajoMolinos": s.idArea,
            "fechaEntrada": s.fechaEntrada!.toIso8601String(),
            "horaEntrada": horaEntradaDt.toIso8601String(),
            "cantidadEntrada": s.cantidadEntrada,
            "fechaSalida": s.fechaSalida!.toIso8601String(),
            "horaSalida": horaSalidaDt.toIso8601String(),
            "cantidadSalida": _usaDobleCantidad(s.nombre)
                ? (s.cantidadPolvo ?? 0) + (s.cantidadTe ?? 0)
                : s.cantidadSalida,
            "cantidadPolvo": s.cantidadPolvo ?? 0,
            "cantidadTe": s.cantidadTe ?? 0,
            "operadoresIds": s.operadoresIds,
            "idEquipoTrabajo": s.equipoSeleccionado?.idEquipo,
          };
        })
        .toList();

    // 3️⃣ Payload final
    final body = {
      // 🔑 SOLO EN UPDATE
      if (widget.idProcesoMolino != null)
        "idProcesoMolino": widget.idProcesoMolino,

      "idEntradaMolinoDetalle": controlSeleccionado!.id,
      "observaciones": observacionesController.text,
      "detalles": detalles,
    };

    // 4️⃣ URL dinámica
    final url = widget.idProcesoMolino == null
        ? '${ApiConfig.baseUrl}/ProcesosMolinos'
        : '${ApiConfig.baseUrl}/ProcesosMolinos/ActualizarProcesoMolinos';

    // 5️⃣ Envío HTTP
    try {
      final response = await http.post( // o PUT si quieres ser REST-purista
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        _mostrarExito(
          widget.idProcesoMolino == null
              ? 'Proceso guardado correctamente'
              : 'Proceso actualizado correctamente',
        );
      } else {
        _mostrarError(response.body);
      }
    } catch (e) {
      _mostrarError('Error de conexión $e');
    }
  }

  Future<bool?> _mostrarConfirmacion(String mensaje) 
  {
    return showDialog<bool>
    (
      context: context,
      barrierDismissible: false,
      builder: (context) 
      {
        return AlertDialog
        (
          title: const Text('Confirmación'),
          content: Text(mensaje),
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(12),
          ),
          actions: 
          [
            TextButton
            (
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton
            (
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Confirmar'),
            ),
          ],
        );
      },
    );
  }

  DateTime _combinarFechaHora(DateTime fecha, TimeOfDay hora) 
  {
    return DateTime
    (
      fecha.year,
      fecha.month,
      fecha.day,
      hora.hour,
      hora.minute,
    );
  }

  void _mostrarError(String mensaje) 
  {
    showDialog
    (
      context: context,
      builder: (context) 
      {
        return AlertDialog
        (
          title: Row(
            children: const 
            [
              Icon(Icons.error_outline, color: Colors.red),
              SizedBox(width: 8),
              
              Text('Error'),
            ],
          ),
          content: Text(mensaje),
          actions: 
          [
            TextButton
            (
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  void _mostrarExito(String mensaje) 
  {
    showDialog
    (
      context: context,
      builder: (context) 
      {
        return Dialog
        (
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column
            (
              mainAxisSize: MainAxisSize.min,
              children: 
              [
                const Icon
                (
                  Icons.check_circle,
                  color: Colors.green,
                  size: 64,
                ),
                const SizedBox(height: 16),
                const Text
                (
                  '¡Operación exitosa!',
                  style: TextStyle
                  (
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text
                (
                  mensaje,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                ElevatedButton
                (
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Aceptar'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) 
  {
      return DefaultTabController
      (
        length: 2,
        child: Scaffold
        (
          backgroundColor: const Color(0xFFF2F2F2),
          appBar: AppBar(
            title: const Text('Procesos'),
            backgroundColor: const Color(0xFF66BB6A),

            bottom: const TabBar(
              indicatorColor: Colors.white,
              tabs: [
                Tab(icon: Icon(Icons.factory)),        // Proceso
                Tab(icon: Icon(Icons.view_list)),      // En curso
              ],
            ),
          ),    

          body: TabBarView
          (
            children: 
            [
              SingleChildScrollView
              (
                padding: const EdgeInsets.all(16),
                child: Card
                (
                  elevation: 4,
                  shape: RoundedRectangleBorder
                  (
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding
                  (
                    padding: const EdgeInsets.all(20),
                    child: Column
                    (
                      children:
                      [ 
                        Align
                        (
                          alignment: Alignment.center,
                          child: Text
                          (
                            'Registro de nuevo proceso de molinos',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF2E7D32),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),

                      DropdownButtonFormField<ControlEntradaMolino>
                      (
                        value: controlSeleccionado,
                        decoration: InputDecoration
                        (
                          labelText: 'Control',
                          border: OutlineInputBorder
                          (
                            borderRadius: BorderRadius.circular(12),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                        items: controles.map((control)
                        {
                          return DropdownMenuItem<ControlEntradaMolino>
                          (
                            value: control,
                            child: Text(control.controlMP),
                        );
                        }).toList(),
                        onChanged: (value)
                        {
                          setState(()
                          {
                            controlSeleccionado = value;
                          });
                        },
                      ),
                      const SizedBox(height: 16),              

                      const Text
                      (
                        'Salidas del Proceso',
                        style: TextStyle
                        (
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),

                      Column
                      (
                        children: secciones.map(_seccionProceso).toList(),
                      ),
                      const SizedBox(height: 16),

                        TextFormField
                        (
                          controller: observacionesController,
                          maxLines: 4, // 🔥 multilínea
                          keyboardType: TextInputType.multiline,
                          decoration: InputDecoration
                          (
                            labelText: 'Observaciones',
                            hintText: 'Escribe aquí cualquier comentario adicional...',
                            alignLabelWithHint: true, // 👈 importante en multiline
                            border: OutlineInputBorder
                            (
                              borderRadius: BorderRadius.circular(12),
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            prefixIcon: const Icon(Icons.notes),
                          ),
                        ),
                        const SizedBox(height: 20),

                        SizedBox
                        (
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton.icon
                          (
                            icon: const Icon(Icons.save),
                            label: const Text('Registrar'),
                          
                            style: ElevatedButton.styleFrom
                            (
                              backgroundColor: const Color(0xFF66BB6A),
                              foregroundColor: const Color(0XFFF4F4F4),
                              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                            ),
                            onPressed: _enviarProceso,
                          )
                        )
                      ],
                    ),
                  ),
                ),
              ),

              // Tab 2
              const ProcesosEnCursoPage(),
            ] 
          )
        ),
    );
  }

  Widget _seccionProceso(SeccionProceso s) {
    List<EquipoTrabajo> _equiposPorSeccion(String nombre) {
      if (nombre == 'Molino') {
        return equipoTrabajo.where((e) =>
          e.descripcion.contains('Molino') ||
          e.descripcion == 'NUTRIBULLER'
        ).toList();
      }

      if (nombre == 'Tamizador') {
        return equipoTrabajo.where((e) =>
          e.descripcion == 'TAMIZ' ||
          e.descripcion == 'COLADOR'
        ).toList();
      }

      return [];
    }

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// CHECK PRINCIPAL
            CheckboxListTile(
              controlAffinity: ListTileControlAffinity.leading,
              value: s.activo,
              title: Text(
                s.nombre,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              onChanged: (value) {
                setState(() => s.activo = value!);
              },
            ),

            if (s.activo && (s.nombre == 'Molino' || s.nombre == 'Tamizador')) ...[
              const SizedBox(height: 10),

              DropdownButtonFormField<EquipoTrabajo>(
                value: s.equipoSeleccionado,
                decoration: InputDecoration(
                  labelText: 'Equipo',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
                items: _equiposPorSeccion(s.nombre).map((eq) {
                  return DropdownMenuItem<EquipoTrabajo>(
                    value: eq,
                    child: Text(eq.descripcion),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    s.equipoSeleccionado = value;
                  });
                },
              ),
            ],

            if (s.activo) ...[
              const Divider(),

              _campoFecha('Fecha entrada', s.fechaEntrada, (v) {
                setState(() => s.fechaEntrada = v);
              }),

              _campoHora('Hora entrada', s.horaEntrada, (v) {
                setState(() => s.horaEntrada = v);
              }),

              _campoNumero('Cantidad entrada',
                s.cantidadEntradaCtrl,
                (v) => s.cantidadEntrada = v
              ),

              _campoFecha('Fecha salida', s.fechaSalida, (v) {
                setState(() => s.fechaSalida = v);
              }),

              _campoHora('Hora salida', s.horaSalida, (v) {
                setState(() => s.horaSalida = v);
              }),

              if (_usaDobleCantidad(s.nombre)) ...[
                _campoNumero('Cantidad polvo',
                  s.cantidadSalidaCtrl,
                  (v) => s.cantidadSalida = v
                ),

                _campoNumero('Cantidad té',
                  s.cantidadTeCtrl,
                  (v) => s.cantidadTe = v
                ),
              ] else ...[
                _campoNumero('Cantidad salida',
                  s.cantidadSalidaCtrl,
                  (v) => s.cantidadSalida = v
                ),
              ],

              const SizedBox(height: 12),
              const Text('Operadores', style: TextStyle(fontWeight: FontWeight.bold)),

              ...operadores.map((op) {
              return CheckboxListTile(
                controlAffinity: ListTileControlAffinity.leading,
                dense: true,
                title: Text(op.nombre),
                value: s.operadoresIds.contains(op.idOperador),
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      s.operadoresIds.add(op.idOperador);
                    } else {
                      s.operadoresIds.remove(op.idOperador);
                    }
                  });
                },
              );
            }).toList(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _campoFecha(String label, DateTime? valor, Function(DateTime) onPick) {
    return TextFormField(
      readOnly: true,
      decoration: InputDecoration
      (
        labelText: label,
        prefixIcon: const Icon(Icons.calendar_today, size: 19),
      ),
      controller: TextEditingController(
        text: valor == null ? '' : '${valor.day}/${valor.month}/${valor.year}',
      ),
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (picked != null) onPick(picked);
      },
    );
  }

  Widget _campoHora(String label, TimeOfDay? valor, Function(TimeOfDay) onPick) {
    return TextFormField(
      readOnly: true,
      decoration: InputDecoration
      (
        labelText: label,
        prefixIcon: const Icon(Icons.access_time, size: 19)
      ),
      controller: TextEditingController(
        text: valor == null ? '' : valor.format(context),
      ),
      onTap: () async {
        final picked = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );
        if (picked != null) onPick(picked);
      },
    );
  }

  Widget _campoNumero(
    String label,
    TextEditingController controller,
    Function(double?) onChange,
  ) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.scale, size: 19),
      ),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (v) => onChange(double.tryParse(v)),
    );
  }
}

bool _usaDobleCantidad(String nombre) {
  return nombre == 'Tamizador' ||
         nombre == 'Tolva de imanes' ||
         nombre == 'Charolas de desinfección';
}