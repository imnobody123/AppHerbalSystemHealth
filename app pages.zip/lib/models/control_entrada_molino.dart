class ControlEntradaMolino {
  final int id;
  final int idProcesoMolino;
  final String controlMP;

  ControlEntradaMolino({
    required this.id,
    required this.idProcesoMolino,
    required this.controlMP,
  });

  factory ControlEntradaMolino.fromJson(Map<String, dynamic> json) {
    return ControlEntradaMolino(
      id: json['idEntradaMolinoDetalle'],
      idProcesoMolino: json['idProcesoMolino'],
      controlMP: json['controlMP'],
    );
  }
}
